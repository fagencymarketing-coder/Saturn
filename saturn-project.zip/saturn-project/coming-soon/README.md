# Заглушки «сайт скоро откроется»

Самодостаточные HTML (логотип вшит) + превью PNG. Открываются в браузере как есть.
Финал не выбран — см. docs/OPEN-QUESTIONS.md.

## Светлые (light/)
- saturn-coming-soon-white          чистый белый фон
- saturn-coming-soon-light          / -light-plain / -light-clean   мягкий фон / без паттерна / mesh-градиент
- saturn-coming-soon-light-pattern  паттерн из полукругов в слоях справа
- saturn-coming-soon-light-ref      оранжевые «бумажные» слои справа (референс)
- saturn-coming-soon-light-ref-green   то же + зелёные акценты (кнопка/статус/иконки)
- saturn-coming-soon-wheat-light    колосья пшеницы справа + зелёные акценты

## Тёмные (dark/)
- saturn-coming-soon                тёмный + фирменный паттерн
- saturn-coming-soon-dark-plain     тёмный без паттерна
- saturn-coming-soon-dark-ref       оранжевые слои справа
- saturn-coming-soon-dark-ref-green то же + зелёные акценты
